
package reservation;

/**
 * @author Manzoor Ahmed
 */
public class Seat {

       public boolean isEmpty = true;  //Initially, seat is empty
       public  Passenger pass;
       
       /**seat with no passenger
        * */
       public Seat(){

       }
       /**constructor
        * @param pass, the passenger
        * */
       public Seat(Passenger pass){
         add(pass);
       }
       /*@param p, passenger to be added to the seat**/
       private void add(Passenger p){
           this.pass =p;
       }
       /*@param p, passenger to be added to the seat**/
       public void setPerson(Passenger p){
           this.pass=p;
       }
       /*@return false, if seat is not empty, true otherwise**/
       public void seatIstaken(){
           this.isEmpty = false;
       }

    @Override
       public String toString(){
           return "Passenger name :  " +this.pass.getName();
       }
}
